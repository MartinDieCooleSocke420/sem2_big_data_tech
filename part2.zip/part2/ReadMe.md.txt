This is the second part of my Big Data Technology SoSe2024 assignment.

The assignment is in the PDF file, the first part is in Data Stream Processing and the presentation is in the Big Data Applications folder.
